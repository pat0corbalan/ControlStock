"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Edit, Trash2, AlertTriangle } from "lucide-react"

interface Product {
  id: string
  name: string
  sku: string
  category: string
  stock: number
  cost: number
  price: number
}

interface ProductsTableProps {
  products: Product[]
  onEdit: (product: Product) => void
  onDelete: (productId: string) => void
}

export function ProductsTable({ products, onEdit, onDelete }: ProductsTableProps) {
  const [deleteProduct, setDeleteProduct] = useState<Product | null>(null)

  const handleDelete = () => {
    if (deleteProduct) {
      onDelete(deleteProduct.id)
      setDeleteProduct(null)
    }
  }

  const getStockStatus = (stock: number) => {
    if (stock <= 5) return { variant: "destructive" as const, label: "Stock Crítico" }
    if (stock <= 10) return { variant: "secondary" as const, label: "Stock Bajo" }
    return { variant: "default" as const, label: "Stock Normal" }
  }

  if (products.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <div className="text-muted-foreground text-center">
            <p className="text-lg mb-2">No se encontraron productos</p>
            <p className="text-sm">Intenta ajustar los filtros de búsqueda</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Productos ({products.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-2 font-medium text-muted-foreground">Producto</th>
                  <th className="text-left py-3 px-2 font-medium text-muted-foreground">SKU</th>
                  <th className="text-left py-3 px-2 font-medium text-muted-foreground">Categoría</th>
                  <th className="text-center py-3 px-2 font-medium text-muted-foreground">Stock</th>
                  <th className="text-right py-3 px-2 font-medium text-muted-foreground">Costo</th>
                  <th className="text-right py-3 px-2 font-medium text-muted-foreground">Precio</th>
                  <th className="text-right py-3 px-2 font-medium text-muted-foreground">Margen</th>
                  <th className="text-center py-3 px-2 font-medium text-muted-foreground">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => {
                  const stockStatus = getStockStatus(product.stock)
                  const margin = (((product.price - product.cost) / product.cost) * 100).toFixed(1)

                  return (
                    <tr key={product.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-2">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{product.name}</span>
                          {product.stock <= 5 && <AlertTriangle className="h-4 w-4 text-destructive" />}
                        </div>
                      </td>
                      <td className="py-3 px-2 text-muted-foreground">{product.sku}</td>
                      <td className="py-3 px-2">
                        <Badge variant="outline">{product.category}</Badge>
                      </td>
                      <td className="py-3 px-2 text-center">
                        <Badge variant={stockStatus.variant}>{product.stock} unidades</Badge>
                      </td>
                      <td className="py-3 px-2 text-right">${product.cost.toFixed(2)}</td>
                      <td className="py-3 px-2 text-right font-medium">${product.price.toFixed(2)}</td>
                      <td className="py-3 px-2 text-right text-primary">+{margin}%</td>
                      <td className="py-3 px-2">
                        <div className="flex justify-center gap-2">
                          <Button variant="ghost" size="sm" onClick={() => onEdit(product)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => setDeleteProduct(product)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={!!deleteProduct} onOpenChange={() => setDeleteProduct(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar producto?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. El producto "{deleteProduct?.name}" será eliminado permanentemente del
              inventario.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
