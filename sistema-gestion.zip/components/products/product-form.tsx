"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"

interface ProductFormData {
  name: string
  sku: string
  category: string
  stock: number
  cost: number
  price: number
}

interface ProductFormProps {
  initialData?: ProductFormData
  onSubmit: (data: ProductFormData) => void
  onCancel: () => void
}

const categories = [
  "Bebidas",
  "Endulzantes",
  "Aceites",
  "Granos",
  "Lácteos",
  "Carnes",
  "Verduras",
  "Frutas",
  "Panadería",
  "Limpieza",
]

export function ProductForm({ initialData, onSubmit, onCancel }: ProductFormProps) {
  const [formData, setFormData] = useState<ProductFormData>(
    initialData || {
      name: "",
      sku: "",
      category: "",
      stock: 0,
      cost: 0,
      price: 0,
    },
  )

  const [errors, setErrors] = useState<Partial<ProductFormData>>({})

  const handleChange = (field: keyof ProductFormData, value: string | number) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }))
    }
  }

  const validateForm = () => {
    const newErrors: Partial<ProductFormData> = {}

    if (!formData.name.trim()) newErrors.name = "El nombre es requerido"
    if (!formData.sku.trim()) newErrors.sku = "El SKU es requerido"
    if (!formData.category) newErrors.category = "La categoría es requerida"
    if (formData.stock < 0) newErrors.stock = "El stock no puede ser negativo"
    if (formData.cost <= 0) newErrors.cost = "El costo debe ser mayor a 0"
    if (formData.price <= 0) newErrors.price = "El precio debe ser mayor a 0"
    if (formData.price <= formData.cost) newErrors.price = "El precio debe ser mayor al costo"

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (validateForm()) {
      onSubmit(formData)
    }
  }

  const margin = formData.cost > 0 ? (((formData.price - formData.cost) / formData.cost) * 100).toFixed(1) : "0"

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Nombre del Producto *</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => handleChange("name", e.target.value)}
            placeholder="Ej: Café Premium 500g"
            className={errors.name ? "border-destructive" : ""}
          />
          {errors.name && <p className="text-sm text-destructive">{errors.name}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="sku">SKU / Código *</Label>
          <Input
            id="sku"
            value={formData.sku}
            onChange={(e) => handleChange("sku", e.target.value.toUpperCase())}
            placeholder="Ej: CAF001"
            className={errors.sku ? "border-destructive" : ""}
          />
          {errors.sku && <p className="text-sm text-destructive">{errors.sku}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="category">Categoría *</Label>
          <Select value={formData.category} onValueChange={(value) => handleChange("category", value)}>
            <SelectTrigger className={errors.category ? "border-destructive" : ""}>
              <SelectValue placeholder="Seleccionar categoría" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.category && <p className="text-sm text-destructive">{errors.category}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="stock">Stock Inicial *</Label>
          <Input
            id="stock"
            type="number"
            min="0"
            value={formData.stock}
            onChange={(e) => handleChange("stock", Number.parseInt(e.target.value) || 0)}
            placeholder="0"
            className={errors.stock ? "border-destructive" : ""}
          />
          {errors.stock && <p className="text-sm text-destructive">{errors.stock}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="cost">Costo Unitario * ($)</Label>
          <Input
            id="cost"
            type="number"
            min="0"
            step="0.01"
            value={formData.cost}
            onChange={(e) => handleChange("cost", Number.parseFloat(e.target.value) || 0)}
            placeholder="0.00"
            className={errors.cost ? "border-destructive" : ""}
          />
          {errors.cost && <p className="text-sm text-destructive">{errors.cost}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="price">Precio de Venta * ($)</Label>
          <Input
            id="price"
            type="number"
            min="0"
            step="0.01"
            value={formData.price}
            onChange={(e) => handleChange("price", Number.parseFloat(e.target.value) || 0)}
            placeholder="0.00"
            className={errors.price ? "border-destructive" : ""}
          />
          {errors.price && <p className="text-sm text-destructive">{errors.price}</p>}
        </div>
      </div>

      {/* Resumen de margen */}
      {formData.cost > 0 && formData.price > 0 && (
        <Card>
          <CardContent className="pt-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Margen de ganancia:</span>
              <span className={`font-medium ${Number.parseFloat(margin) > 0 ? "text-primary" : "text-destructive"}`}>
                +{margin}% (${(formData.price - formData.cost).toFixed(2)})
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1 bg-transparent">
          Cancelar
        </Button>
        <Button type="submit" className="flex-1">
          {initialData ? "Actualizar Producto" : "Agregar Producto"}
        </Button>
      </div>
    </form>
  )
}
