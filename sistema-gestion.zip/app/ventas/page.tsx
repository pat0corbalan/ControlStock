"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { NewSaleForm } from "@/components/sales/new-sale-form"
import { SalesList } from "@/components/sales/sales-list"
import { SaleReceipt } from "@/components/sales/sale-receipt"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Plus, Receipt } from "lucide-react"

// Datos de ejemplo para ventas
const initialSales = [
  {
    id: "V001",
    date: "2024-01-15T10:30:00",
    customer: "María González",
    items: [
      { name: "Café Premium 500g", quantity: 2, price: 12.99 },
      { name: "Azúcar Blanca 1kg", quantity: 1, price: 2.5 },
    ],
    subtotal: 28.48,
    total: 28.48,
    paymentMethod: "Efectivo",
    status: "Pagado",
  },
  {
    id: "V002",
    date: "2024-01-15T14:15:00",
    customer: "Carlos Rodríguez",
    items: [
      { name: "Aceite de Oliva 500ml", quantity: 1, price: 9.99 },
      { name: "Arroz Integral 1kg", quantity: 3, price: 3.75 },
    ],
    subtotal: 21.24,
    total: 21.24,
    paymentMethod: "A pagar",
    status: "Pendiente",
  },
  {
    id: "V003",
    date: "2024-01-15T16:45:00",
    customer: "Ana López",
    items: [{ name: "Leche Entera 1L", quantity: 4, price: 2.99 }],
    subtotal: 11.96,
    total: 11.96,
    paymentMethod: "Tarjeta de crédito",
    status: "Pagado",
  },
]

export default function SalesPage() {
  const [sales, setSales] = useState(initialSales)
  const [showNewSaleForm, setShowNewSaleForm] = useState(false)
  const [selectedSale, setSelectedSale] = useState(null)
  const [showReceipt, setShowReceipt] = useState(false)

  const handleNewSale = (saleData) => {
    const newSale = {
      ...saleData,
      id: `V${String(sales.length + 1).padStart(3, "0")}`,
      date: new Date().toISOString(),
      status: saleData.paymentMethod === "A pagar" ? "Pendiente" : "Pagado",
    }
    setSales([newSale, ...sales])
    setSelectedSale(newSale)
    setShowNewSaleForm(false)
    setShowReceipt(true)
  }

  const handleUpdateSaleStatus = (saleId, newStatus) => {
    setSales(sales.map((sale) => (sale.id === saleId ? { ...sale, status: newStatus } : sale)))
  }

  const todaySales = sales.filter((sale) => {
    const saleDate = new Date(sale.date)
    const today = new Date()
    return saleDate.toDateString() === today.toDateString()
  })

  const todayTotal = todaySales.reduce((sum, sale) => sum + sale.total, 0)
  const pendingPayments = sales.filter((sale) => sale.status === "Pendiente").reduce((sum, sale) => sum + sale.total, 0)

  return (
    <div className="flex min-h-screen bg-background">
      <Navigation />

      <main className="flex-1 md:ml-64">
        <div className="p-6">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-foreground">Sistema de Ventas</h1>
            <p className="text-muted-foreground">Registra nuevas ventas y gestiona el historial</p>
          </div>

          {/* Resumen del día */}
          <div className="grid gap-4 md:grid-cols-3 mb-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Ventas del Día</CardTitle>
                <Receipt className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${todayTotal.toFixed(2)}</div>
                <p className="text-xs text-muted-foreground">{todaySales.length} ventas realizadas</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pagos Pendientes</CardTitle>
                <Receipt className="h-4 w-4 text-chart-2" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-chart-2">${pendingPayments.toFixed(2)}</div>
                <p className="text-xs text-muted-foreground">
                  {sales.filter((s) => s.status === "Pendiente").length} facturas pendientes
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex items-center justify-center p-6">
                <Button onClick={() => setShowNewSaleForm(true)} className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Nueva Venta
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Lista de ventas */}
          <SalesList
            sales={sales}
            onViewReceipt={(sale) => {
              setSelectedSale(sale)
              setShowReceipt(true)
            }}
            onUpdateStatus={handleUpdateSaleStatus}
          />

          {/* Modal de nueva venta */}
          <Dialog open={showNewSaleForm} onOpenChange={setShowNewSaleForm}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Nueva Venta</DialogTitle>
              </DialogHeader>
              <NewSaleForm onSubmit={handleNewSale} onCancel={() => setShowNewSaleForm(false)} />
            </DialogContent>
          </Dialog>

          {/* Modal de comprobante */}
          <Dialog open={showReceipt} onOpenChange={setShowReceipt}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Comprobante de Venta</DialogTitle>
              </DialogHeader>
              {selectedSale && <SaleReceipt sale={selectedSale} onClose={() => setShowReceipt(false)} />}
            </DialogContent>
          </Dialog>
        </div>
      </main>
    </div>
  )
}
