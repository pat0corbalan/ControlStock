"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { ProductsTable } from "@/components/products/products-table"
import { ProductForm } from "@/components/products/product-form"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Plus, Search } from "lucide-react"

// Datos de ejemplo para productos
const initialProducts = [
  {
    id: "1",
    name: "Café Premium 500g",
    sku: "CAF001",
    category: "Bebidas",
    stock: 25,
    cost: 8.5,
    price: 12.99,
  },
  {
    id: "2",
    name: "Azúcar Blanca 1kg",
    sku: "AZU001",
    category: "Endulzantes",
    stock: 15,
    cost: 1.2,
    price: 2.5,
  },
  {
    id: "3",
    name: "Aceite de Oliva 500ml",
    sku: "ACE001",
    category: "Aceites",
    stock: 8,
    cost: 5.75,
    price: 9.99,
  },
  {
    id: "4",
    name: "Arroz Integral 1kg",
    sku: "ARR001",
    category: "Granos",
    stock: 30,
    cost: 2.1,
    price: 3.75,
  },
  {
    id: "5",
    name: "Leche Entera 1L",
    sku: "LEC001",
    category: "Lácteos",
    stock: 12,
    cost: 1.8,
    price: 2.99,
  },
]

const categories = ["Todas", "Bebidas", "Endulzantes", "Aceites", "Granos", "Lácteos"]

export default function ProductsPage() {
  const [products, setProducts] = useState(initialProducts)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("Todas")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState(null)

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "Todas" || product.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const handleAddProduct = (productData) => {
    const newProduct = {
      ...productData,
      id: Date.now().toString(),
    }
    setProducts([...products, newProduct])
    setIsAddDialogOpen(false)
  }

  const handleEditProduct = (productData) => {
    setProducts(products.map((p) => (p.id === editingProduct.id ? { ...productData, id: editingProduct.id } : p)))
    setEditingProduct(null)
  }

  const handleDeleteProduct = (productId) => {
    setProducts(products.filter((p) => p.id !== productId))
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Navigation />

      <main className="flex-1 md:ml-64">
        <div className="p-6">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-foreground">Gestión de Productos</h1>
            <p className="text-muted-foreground">Administra tu inventario y catálogo de productos</p>
          </div>

          {/* Filtros y búsqueda */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Buscar por nombre o SKU..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filtrar por categoría" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="w-full sm:w-auto">
                  <Plus className="h-4 w-4 mr-2" />
                  Agregar Producto
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Agregar Nuevo Producto</DialogTitle>
                </DialogHeader>
                <ProductForm onSubmit={handleAddProduct} onCancel={() => setIsAddDialogOpen(false)} />
              </DialogContent>
            </Dialog>
          </div>

          {/* Tabla de productos */}
          <ProductsTable products={filteredProducts} onEdit={setEditingProduct} onDelete={handleDeleteProduct} />

          {/* Modal de edición */}
          <Dialog open={!!editingProduct} onOpenChange={() => setEditingProduct(null)}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Editar Producto</DialogTitle>
              </DialogHeader>
              {editingProduct && (
                <ProductForm
                  initialData={editingProduct}
                  onSubmit={handleEditProduct}
                  onCancel={() => setEditingProduct(null)}
                />
              )}
            </DialogContent>
          </Dialog>
        </div>
      </main>
    </div>
  )
}
